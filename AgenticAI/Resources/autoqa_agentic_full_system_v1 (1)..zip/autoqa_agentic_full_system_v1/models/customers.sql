select * from {{ ref('customers_src') }}
