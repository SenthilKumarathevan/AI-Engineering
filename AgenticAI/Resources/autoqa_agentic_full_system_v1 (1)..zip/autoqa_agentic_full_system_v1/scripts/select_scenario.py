
from pathlib import Path
import shutil, sys
ROOT = Path(__file__).resolve().parents[1]
SCENARIO = sys.argv[1] if len(sys.argv)>1 else 'scenario_default'
SRC = ROOT / 'test_data' / SCENARIO
DST = ROOT / 'seeds'
if not SRC.exists():
    raise SystemExit(f"Scenario not found: {SRC}")
DST.mkdir(exist_ok=True)
for p in DST.glob('*.csv'):
    p.unlink()
for p in SRC.glob('*.csv'):
    shutil.copy2(p, DST / p.name)
print(f"Loaded scenario '{SCENARIO}' into seeds/: {[p.name for p in DST.glob('*.csv')]}")
