
from pathlib import Path
import json, yaml

ROOT = Path(__file__).resolve().parents[1]
RULES = ROOT/'config'/'rules.json'
MODELS_DIR = ROOT/'models'
TESTS_DIR = ROOT/'tests'

MODELS_DIR.mkdir(exist_ok=True)
TESTS_DIR.mkdir(exist_ok=True)

def write_schema_yaml(rules):
    schema = {'version':2,'models':[]}
    for m in rules['models']:
        entry = {'name': m['name'], 'columns': []}
        # columns tests
        for col, tests in m.get('columns',{}).items():
            # normalize accepted_values shape
            norm = []
            for t in tests:
                if isinstance(t,str):
                    norm.append(t)
                elif isinstance(t,dict) and 'accepted_values' in t:
                    av = t['accepted_values']
                    if isinstance(av,dict):
                        norm.append({'accepted_values': {'values': av.get('values',[])}})
                    else:
                        norm.append({'accepted_values': {'values': list(av)}})
            entry['columns'].append({'name': col, 'tests': norm})
        schema['models'].append(entry)
        # relationships handled via YAML generic test if provided
        if m.get('relationships'):
            # append a block per relationship as a column test on source column using generic relationships
            for rel in m['relationships']:
                # attach to model-level tests as columns augmentation
                entry['columns'].append({'name': rel['column'], 'tests':[{'relationships': {'to': f"ref('{rel['to_model']}')", 'field': rel['to_column']}}]})
    (MODELS_DIR/'schema_autoqa.yml').write_text(yaml.dump(schema, sort_keys=False, allow_unicode=True), encoding='utf-8')


def write_row_rule_tests(rules):
    # T1 mode: one SQL test file per rule per model
    for m in rules['models']:
        model = m['name']
        for i, rule in enumerate(m.get('row_rules', []), start=1):
            sql = f"""
-- Auto-generated business rule test {i} for {model}
SELECT * FROM {{ ref('{model}') }}
WHERE NOT ({rule})
""".strip()+"
"
            (TESTS_DIR / f"test_{model}_rule_{i}.sql").write_text(sql, encoding='utf-8')


def main():
    rules = json.loads(RULES.read_text(encoding='utf-8'))
    write_schema_yaml(rules)
    write_row_rule_tests(rules)
    print('Rendered dbt schema and tests (T1 mode).')

if __name__=='__main__':
    main()
