
from pathlib import Path
import json, re, datetime

ROOT = Path(__file__).resolve().parents[1]
RULES_FILE = ROOT/'config'/'rules.json'
HIST = ROOT/'rules_history'
HIST.mkdir(exist_ok=True)

GT_TO_GE = re.compile(r"([\w\.]+)\s*>\s*0")


def relax(rule:str)->str:
    s = rule
    s = GT_TO_GE.sub(lambda m: f"{m.group(1)} >= 0", s)
    return s


def main():
    rules = json.loads(RULES_FILE.read_text(encoding='utf-8'))
    before = json.dumps(rules,indent=2)
    changed = False
    for m in rules.get('models',[]):
        rr = m.get('row_rules',[])
        new = []
        for r in rr:
            nr = relax(r)
            if nr!=r: changed=True
            new.append(nr)
        m['row_rules'] = new
    if changed:
        ts = datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        (HIST/f'rules_before_{ts}.json').write_text(before,encoding='utf-8')
        RULES_FILE.write_text(json.dumps(rules,indent=2),encoding='utf-8')
        print('[Heuristic] rules.json updated.')
    else:
        print('[Heuristic] No changes applied.')

if __name__=='__main__':
    main()
