
import streamlit as st
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
REPORT = ROOT/'reports'/'dbt_test_report.txt'
COV = ROOT/'reports'/'test_coverage.json'
AUTO = ROOT/'test_data'/'auto_generated'

st.set_page_config(page_title='AutoQA Agentic (AGG-MAX)', layout='wide')
st.title('AutoQA Agentic – Local (Foundry Local, AGG-MAX, T1)')

cols = st.columns(3)
cols[0].write('**Mode:** AGG-MAX (aggressive coverage)')
cols[1].write('**LLM Provider:** Foundry Local (OpenAI-compatible)')
cols[2].write('**Tests layout:** T1 (SQL files in tests/)')

st.header('Coverage')
if COV.exists():
    cov = json.loads(COV.read_text(encoding='utf-8'))
    m = st.columns(3)
    m[0].metric('Columns Covered (%)', cov.get('columns_pct',0))
    m[1].metric('Models', cov.get('models_total',0))
    m[2].metric('Models with Business Rules', cov.get('models_with_business_rules',0))
else:
    st.info('Run the pipeline once to compute coverage.')

st.header('DBT Test Output (Tail)')
if REPORT.exists():
    st.code(REPORT.read_text(encoding='utf-8')[-25000:])
else:
    st.info('No dbt report yet. Run the pipeline.')

st.header('Auto-generated Scenarios')
if AUTO.exists():
    for scen in sorted(AUTO.iterdir()):
        st.subheader(scen.name)
        for p in scen.glob('*.csv'):
            st.write(p.name)
            st.code(p.read_text(encoding='utf-8'))
else:
    st.info('No auto scenarios yet.')
