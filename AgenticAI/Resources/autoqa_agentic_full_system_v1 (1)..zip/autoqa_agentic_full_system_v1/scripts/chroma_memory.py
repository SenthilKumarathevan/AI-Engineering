
import chromadb
from chromadb.config import Settings

class ChromaMemory:
    def __init__(self, path='chroma/db'):
        self.client = chromadb.PersistentClient(path, settings=Settings(anonymized_telemetry=False))
        self.fail = self.client.get_or_create_collection('fail')
        self.meta = self.client.get_or_create_collection('meta')
        self.plans = self.client.get_or_create_collection('plans')
        self.dim = 32
    def _emb(self):
        return [0.0]*self.dim
    def store_failure(self, text:str):
        cur = self.fail.get(ids=None).get('ids',[])
        new_id = f'f_{len(cur)}'
        self.fail.add(documents=[text], ids=[new_id], embeddings=[self._emb()])
        return new_id
    def store_plan(self, text:str):
        cur = self.plans.get(ids=None).get('ids',[])
        new_id = f'p_{len(cur)}'
        self.plans.add(documents=[text], ids=[new_id], embeddings=[self._emb()])
        return new_id
    def store_meta(self, text:str):
        cur = self.meta.get(ids=None).get('ids',[])
        new_id = f'm_{len(cur)}'
        self.meta.add(documents=[text], ids=[new_id], embeddings=[self._emb()])
        return new_id
    def query_failures(self, text:str, k:int=3):
        # no real embeddings; return empty
        return {'documents':[[]]}
