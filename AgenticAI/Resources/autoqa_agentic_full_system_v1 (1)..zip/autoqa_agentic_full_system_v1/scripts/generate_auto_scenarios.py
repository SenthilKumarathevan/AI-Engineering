
from pathlib import Path
import csv, json
from chroma_memory import ChromaMemory

ROOT = Path(__file__).resolve().parents[1]
AUTO = ROOT/'test_data'/'auto_generated'
AUTO.mkdir(exist_ok=True)
mem = ChromaMemory()

# Simple aggressive synthetic: create invalid enums, negative amounts, broken emails
scen = AUTO/'scenario_auto_aggmax_1'
scen.mkdir(exist_ok=True)
(scen/'customers_src.csv').write_text('customer_id,email,status
10,bad_at_example.com,unknown
11,,active
',encoding='utf-8')
(scen/'orders_src.csv').write_text('order_id,customer_id,order_amount,status,created_at
200,10,-99,unknown,2030-01-01
201,11,0,active,2025-01-01
',encoding='utf-8')
mem.store_meta('scenario_auto_aggmax_1')
print('Generated auto scenario at:', scen)
