
import argparse, os, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PROFILES = ROOT/'profiles'
REPORTS = ROOT/'reports'
DATA = ROOT/'data'
DATA.mkdir(exist_ok=True); REPORTS.mkdir(exist_ok=True)


def run(cmd):
    print('> ' + ' '.join(map(str, cmd)))
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.stdout + '
' + p.stderr


def dbt_pipeline():
    out=''
    for c in [['dbt','deps'],['dbt','clean'],['dbt','seed'],['dbt','run'],['dbt','test']]:
        out += run(c + ['--project-dir', str(ROOT), '--profiles-dir', str(PROFILES)])
    return out


def main():
    ap = argparse.ArgumentParser(description='AutoQA Agentic (AGG-MAX, T1)')
    ap.add_argument('--scenario', default='scenario_default')
    ap.add_argument('--self-heal', action='store_true')
    ap.add_argument('--llm-heal', action='store_true')
    ap.add_argument('--auto-generate-scenarios', action='store_true')
    ap.add_argument('--max-iterations', type=int, default=2)
    args = ap.parse_args()

    # windows-safe duckdb path
    os.environ['DUCKDB_PATH'] = str((ROOT/'data'/'autoqa.duckdb')).replace('\','/')

    out=''
    out += run(['python', str(ROOT/'scripts'/'select_scenario.py'), args.scenario])
    out += run(['python', str(ROOT/'scripts'/'detect_and_generate_coverage.py')])
    out += run(['python', str(ROOT/'scripts'/'generate_tests.py')])
    out += dbt_pipeline()

    it=0
    while it < args.max_iterations:
        it+=1
        if args.self_heal:
            out += run(['python', str(ROOT/'scripts'/'self_heal_rules.py')])
            out += run(['python', str(ROOT/'scripts'/'generate_tests.py')])
            out += dbt_pipeline()
        elif args.llm_heal:
            out += run(['python', str(ROOT/'scripts'/'llm_agent.py')])
            out += run(['python', str(ROOT/'scripts'/'generate_tests.py')])
            out += dbt_pipeline()
        elif args.auto_generate_scenarios:
            out += run(['python', str(ROOT/'scripts'/'generate_auto_scenarios.py')])
            out += run(['python', str(ROOT/'scripts'/'select_scenario.py'), 'auto_generated/scenario_auto_aggmax_1'])
            out += run(['python', str(ROOT/'scripts'/'detect_and_generate_coverage.py')])
            out += run(['python', str(ROOT/'scripts'/'generate_tests.py')])
            out += dbt_pipeline()
        else:
            break

    (REPORTS/'dbt_test_report.txt').write_text(out,encoding='utf-8')
    print('Report saved to reports/dbt_test_report.txt')

if __name__=='__main__':
    main()
