
from pathlib import Path
import os, json
from chroma_memory import ChromaMemory

ROOT = Path(__file__).resolve().parents[1]
CFG = json.loads((ROOT/'config'/'llm.json').read_text(encoding='utf-8'))
RULES = ROOT/'config'/'rules.json'
REPORT = ROOT/'reports'/'dbt_test_report.txt'
PROVIDER = CFG.get('provider','foundry-local')

memory = ChromaMemory()


def analyze():
    if not REPORT.exists(): return []
    txt = REPORT.read_text(encoding='utf-8')
    return [l for l in txt.splitlines() if 'Failure in test' in l or 'FAIL ' in l]


def foundry_client(alias:str):
    from foundry_local import FoundryLocalManager
    from openai import OpenAI
    mgr = FoundryLocalManager(alias)
    return OpenAI(base_url=mgr.endpoint, api_key=mgr.api_key), alias


def build_prompt(failure_text:str, similar_docs:list[str]):
    ctx = "
".join(f"- {d}" for d in similar_docs)
    return f"""
You are a strict AutoQA rules healer. Given dbt failures and existing aggressive rules, return a JSON with a single patch to improve pass rate while keeping data quality high.
Failures:
{failure_text}

Similar historical failures:
{ctx}

Return COMPACT JSON ONLY with this shape:
{{"action":"update_rule","target_model":"<model>","updated_row_rule":"<new_rule>"}}
Use simple SQL predicates compatible with dbt data tests.
"""


def plan(fails:list[str])->dict:
    failure_text = "
".join(fails)
    memory.store_failure(failure_text)
    sim = memory.query_failures(failure_text)
    docs = sim.get('documents',[[]])[0]
    prompt = build_prompt(failure_text, docs)
    try:
        client, model = foundry_client(CFG.get('model_alias','qwen2.5-coder-1.5b'))
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role":"system","content":"Return JSON only"},{"role":"user","content":prompt}],
            temperature=0
        )
        content = resp.choices[0].message.content.strip()
        memory.store_plan(content)
        return json.loads(content)
    except Exception:
        # safe fallback: relax order_amount > 0
        return {"action":"update_rule","target_model":"orders","updated_row_rule":"order_amount >= 0"}


def apply_patch(p:dict)->bool:
    if not p: return False
    rules = json.loads(RULES.read_text(encoding='utf-8'))
    changed=False
    for m in rules.get('models',[]):
        if m.get('name')==p.get('target_model'):
            rr=m.get('row_rules',[])
            if rr:
                rr[0]=p['updated_row_rule']
                m['row_rules']=rr
                changed=True
    if changed:
        RULES.write_text(json.dumps(rules,indent=2),encoding='utf-8')
    return changed

if __name__=='__main__':
    fails=analyze()
    if not fails:
        print('[LLM] No failures found.')
    else:
        p=plan(fails)
        if apply_patch(p):
            print('[LLM] Applied plan:',p)
        else:
            print('[LLM] No change applied.')
